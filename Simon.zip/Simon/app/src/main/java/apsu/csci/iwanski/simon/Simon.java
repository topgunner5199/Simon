package apsu.csci.iwanski.simon;

import java.util.Random;

/**
 * Created by Iwanski on 3/13/2016.
 */
public final class Simon {
    public static final int TOT_BUTTONS=3*3;

    public interface Listener{
        void buttonStateChanged(int index);
        void multipleButtonsChanged();
    }

   // private static final int Sound_time=100;

    //sounds
    private static final int Green = 0;
    private static final int Yellow = 1;
    private static final int Red = 2;
    private static final int Blue = 3;

    //for randomization
    private static final Random rnd = new Random();
    private boolean isPressed;


    public void removeListener(Listener listener) {listeners.remove(listener);)
    }

    public void pressButton(int buttonIndex) {
    }

    public void releaseButton(int buttonIndex) {
    }

    public void releaseAllButtons() {
    }


}
